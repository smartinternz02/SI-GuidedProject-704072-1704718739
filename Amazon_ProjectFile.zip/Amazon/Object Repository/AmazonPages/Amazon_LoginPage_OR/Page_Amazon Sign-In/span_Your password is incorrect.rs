<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Your password is incorrect</name>
   <tag></tag>
   <elementGuidId>6a9e658e-2682-4582-8b16-9fe80f2cfa3e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.a-list-item</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>a13d90b9-3ac1-451f-9715-92fb440eb66b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-list-item</value>
      <webElementGuid>a520255d-f78e-4fa5-a4a7-d6d73ef56f70</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
            Your password is incorrect
          </value>
      <webElementGuid>a256a165-2348-4621-a74c-82241bcb66db</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;auth-error-message-box&quot;)/div[@class=&quot;a-box-inner a-alert-container&quot;]/div[@class=&quot;a-alert-content&quot;]/ul[@class=&quot;a-unordered-list a-nostyle a-vertical a-spacing-none&quot;]/li[1]/span[@class=&quot;a-list-item&quot;]</value>
      <webElementGuid>f25960e4-b8ab-4d33-abfe-594c70d2c5fa</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='auth-error-message-box']/div/div/ul/li/span</value>
      <webElementGuid>dceabb94-f669-4d83-9cb8-61464158ac98</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span</value>
      <webElementGuid>e70dd824-eb18-44a5-9de5-3061b17bb993</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '
            Your password is incorrect
          ' or . = '
            Your password is incorrect
          ')]</value>
      <webElementGuid>b69d6525-8fb6-4405-8442-5b8277a8aa40</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
