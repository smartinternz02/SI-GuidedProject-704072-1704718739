<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_There was a problem                    _7a87af</name>
   <tag></tag>
   <elementGuidId>e91b40ba-03b9-4ae1-b6dc-9bc8bfda4ec2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.a-box-inner.a-alert-container</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='auth-error-message-box']/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>5c70a20e-5f02-476f-917a-a82421f9795b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-box-inner a-alert-container</value>
      <webElementGuid>db24f755-7078-4cfe-92c5-1ca93a600d0d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>There was a problem
      
        
          
        
        
      
      
        
          
            Your password is incorrect
          
        
      
    </value>
      <webElementGuid>cd92033a-2667-4739-b78d-5de115af63d4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;auth-error-message-box&quot;)/div[@class=&quot;a-box-inner a-alert-container&quot;]</value>
      <webElementGuid>90e60cbc-2844-4aaa-a282-1d7b04495648</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='auth-error-message-box']/div</value>
      <webElementGuid>cf1ed3ba-65e6-4f55-aa78-ef6f9eea76cd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div/div/div</value>
      <webElementGuid>2fef5acb-24f9-4660-9282-639d3cbb5e3b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'There was a problem
      
        
          
        
        
      
      
        
          
            Your password is incorrect
          
        
      
    ' or . = 'There was a problem
      
        
          
        
        
      
      
        
          
            Your password is incorrect
          
        
      
    ')]</value>
      <webElementGuid>a770296a-be7d-4108-bd6e-b2ccf343dc3b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
